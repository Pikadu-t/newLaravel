<?php
include("DB.php");
session_start();
$message=""; ?>
<?php

if(count($_POST)>0) {
    $pass=md5($_POST["password"]);
    $result = mysqli_query($conn,"SELECT * FROM user WHERE user_name='" . $_POST["user_name"] . "' and password = '". $pass ."'");
    $row  = mysqli_fetch_array($result);
    if(is_array($row)) {
        $_SESSION["id"] = $row['user_name'];
        $_SESSION["name"] = $row['password'];
    } else {
        $message = "Invalid Username or Password!";
    }
}if(isset($_SESSION["id"])) {
    header("Location:dashboard.php");
}
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>National Election Board of Ethiopia | Log in (v2)</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
    <!-- /.login-logo -->
    <div class="card card-outline card-primary">
        <div class="card-header text-center">
            <a href="#" class="h1"><b>NEBE</b><br><h5>LOGIN</h5></a>
        </div>
        <form name="frmUser" method="post" action="" align="center">
        <div class="card-body">
<!--            <form action="#" class="login-form">-->
                <!--      <form action="dashboard.html" method="post">-->
                <div class="form-group">
                    <input type="text" name = "user_name" class="form-control rounded-left" placeholder="Username" required>
                </div>
                <div class="form-group d-flex">
                    <input type="password" name = "password" class="form-control rounded-left" placeholder="Password" required>
                </div>
                <center><strong style = "color:red;"><?php echo $message; ?></strong></center>
                <div class="row">

                    <!-- /.col -->
                    <div class="col-4">
                        <button  style="alignment: center" type="submit" class="btn btn-primary">Sign In</button>
                    </div>
                    <!-- /.col -->
                </div>
<!--            </form>-->




        </div>
        </form>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<!-- /.login-box -->



<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>
